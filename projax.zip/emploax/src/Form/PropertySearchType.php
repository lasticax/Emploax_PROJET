<?php

namespace App\Form;

use App\Entity\PropertySearch;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;

class PropertySearchType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('dureeMax', IntegerType::class, ['required' => false, 'label' => false, 'attr' => [ 'placeholder'=> 'Durée maximale en mois' ] ])
            ->add('dureeMin', IntegerType::class, ['required' => false, 'label' => false, 'attr' => [ 'placeholder'=> 'Durée minimale en mois' ] ])
            ->add('category', ChoiceType::class, ['required' => false, 'label' => 'Type de contrat : ', 'choices' => ['CDI' => 1, 'CDD' => 2, 'Contrat d\'apprentissage' => 3, 'Contrat de professionnalisation' => 4, 'Stage' => 5] ])
            ->add('region', ChoiceType::class, ['required' => false, 'label' => 'Localisation : ', 'choices' => ['Auvergne-Rhône-Alpes' => 1, 'Bourgogne-Franche-Comté' => 2, 'Bretagne' => 3, 'Centre-Val de Loire' => 4, 'Corse' => 5, 'Grand-Est' => 6, 'Hauts-de-France' => 7, 'Ile-de-France' => 8, 'Normandie' => 9, 'Nouvelle-Aquitaine' => 10, 'Occitanie' => 11, 'Pays de la Loire' => 12, 'Provence-Alpes-Côte d\'Azure' => 13] ])

        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => PropertySearch::class,
            'method' => 'get',
            'csrf_protection' => false
        ]);
    }


    public function getBlockPrefix()
    {
        return'';
    }


}
