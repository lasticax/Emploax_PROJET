<?php
namespace App\Entity;

class PropertySearch
{

    /**
     * @var int|null
     */
    private $dureeMax;

    /**
     * @var int|null
     */
    private $dureeMin;

    /**
     * @var int|null
     */
    private $category;

    /**
     * @var int|null
     */
    private $region;


    /**
     * @return int|null
     */
    public function getDureeMax() : ?int
    {
        return $this->dureeMax;
    }


    /**
     * @param int|null $dureeMax
     * @return PropertySearch
     */
    public function setDureeMax(int $dureeMax): PropertySearch
    {
        $this->dureeMax = $dureeMax;
        return $this;
    }

    /**
     * @return int|null
     */
    public function getDureeMin() : ?int
    {
        return $this->dureeMin;
    }

    /**
     * @param int|null $dureeMin
     * @return PropertySearch
     */
    public function setDureeMin(int $dureeMin): PropertySearch
    {
        $this->dureeMin = $dureeMin;
        return $this;
    }


    
    /**
     * @return int|null
     */
    public function getCategory() : ?int
    {
        return $this->category;
    }


    /**
     * @param int|null $category
     * @return PropertySearch
     */
    public function setCategory(int $category): PropertySearch
    {
        $this->category = $category;
        return $this;
    }

    /**
     * @return int|null
     */
    public function getRegion() : ?int
    {
        return $this->region;
    }


    /**
     * @param int|null $region
     * @return PropertySearch
     */
    public function setRegion(int $region): PropertySearch
    {
        $this->region = $region;
        return $this;
    }
}