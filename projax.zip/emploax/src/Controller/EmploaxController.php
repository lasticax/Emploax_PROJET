<?php

namespace App\Controller;

use App\Entity\Offre;
use App\Entity\Comment;
use App\Form\OffreType;

use App\Form\CommentType;
use App\Entity\PropertySearch;
use App\Form\PropertySearchType;
use App\Repository\UserRepository;
use App\Repository\OffreRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class EmploaxController extends AbstractController
{
    /**
     * @Route("/emploax", name="emploax")
     */
    public function index(OffreRepository $repo, Request $request)
    {
        $search = new PropertySearch();
        $form = $this->createForm(PropertySearchType::class, $search);
        $form->handleRequest($request);



        $offres = $repo->findAllVisibleQuery($search);

        return $this->render('emploax/index.html.twig', [
            'controller_name' => 'EmploaxController',
            'offres' => $offres,
            'form' => $form->createView()
        ]);
    }

    /**
     * @Route("/", name="home")
     */
    public function home()
    {
        return $this->render('emploax/home.html.twig');
    }

    /**
     * @Route("/emploax/new", name="emploax_create")
     * @Route("/emploax/{id}/edit", name="emploax_edit")
     */
    public function form(Offre $offre = null, Request $request, EntityManagerInterface $manager)
    {   
        if(!$offre)
        {
            $offre = new Offre();
        }

        $form = $this->createForm(OffreType::class, $offre);

        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid())
        {
            if(!$offre->getId())
            {
                $offre->setCreatedAt(new \DateTime());
            }
            $manager->persist($offre);
            $manager->flush();
            return $this->redirectToRoute('emploax_show', ['id' => $offre->getId()]);
        }
       return $this->render('emploax/create.html.twig', ['formOffre' => $form->createView(), 'editMode' => $offre->getId() !== null]);
    }

    /**
     * @Route("/emploax/{id}", name="emploax_show")
     */
    public function show(Offre $offre, Request $request, EntityManagerInterface $manager)
    {
        $comment = new Comment();
        $user = $this->getUser();

        $form = $this->createForm(CommentType::class, $comment);
        
        $form->handleRequest($request);
        
        if ($form->isSubmitted() && $form->isValid())
        {
            $comment->setCreatedAt(new \DateTime())
                    ->setOffre($offre)
                    ->setAuthor($user->getUsername());

            $manager->persist($comment);
            $manager->flush();

            return $this->redirectToRoute('emploax_show', ['id' => $offre->getId()]);
        }
        
        return $this->render('emploax/show.html.twig', [
            'offre' => $offre, 'commentForm' => $form->createView()
        ]);
    }
}
